import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _ced967e8 = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _68e8768b = () => interopDefault(import('..\\pages\\predict.vue' /* webpackChunkName: "pages/predict" */))
const _1beeebb6 = () => interopDefault(import('..\\pages\\predict\\city.vue' /* webpackChunkName: "pages/predict/city" */))
const _84695856 = () => interopDefault(import('..\\pages\\predict\\salary.vue' /* webpackChunkName: "pages/predict/salary" */))
const _0b2336f8 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/inspire",
    component: _ced967e8,
    name: "inspire"
  }, {
    path: "/predict",
    component: _68e8768b,
    name: "predict",
    children: [{
      path: "city",
      component: _1beeebb6,
      name: "predict-city"
    }, {
      path: "salary",
      component: _84695856,
      name: "predict-salary"
    }]
  }, {
    path: "/",
    component: _0b2336f8,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
